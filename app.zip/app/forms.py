from django import forms
from .models import Cliente, Servico

class ClienteForm(forms.ModelForm):
    class Meta:
        model = Cliente
        fields = '__all__'

class ServicoForm(forms.ModelForm):
    class Meta:
        model = Servico
        fields = ['cliente', 'data', 'hora_inicio', 'hora_fim', 'tipo_servico', 'fotos']

    hora_inicio = forms.TimeField(label='Hora de Início')
    hora_fim = forms.TimeField(label='Hora de Término')