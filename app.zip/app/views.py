from django.shortcuts import render, redirect, get_object_or_404
from app.forms import ClienteForm, ServicoForm
from .models import Cliente, Servico





def home(request):
    return render(request, 'home.html')

def cliente_list(request):
    clientes = Cliente.objects.all()
    return render(request, 'app/cliente_list.html', {'clientes': clientes})

def cliente_create(request):
    if request.method == 'POST':
        form = ClienteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('cliente_list')
    else:
        form = ClienteForm()
    return render(request, 'app/cliente_form.html', {'form': form})

def cliente_edit(request, pk):
    cliente = Cliente.objects.get(pk=pk)
    if request.method == 'POST':
        form = ClienteForm(request.POST, instance=cliente)
        if form.is_valid():
            form.save()
            return redirect('cliente_list')
    else:
        form = ClienteForm(instance=cliente)
    return render(request, 'app/cliente_form.html', {'form': form})

def cliente_delete(request, pk):
    cliente = get_object_or_404(Cliente, pk=pk)
    if request.method == 'POST':
        cliente.delete()
        return redirect('cliente_list')
    return render(request, 'app/cliente_confirm_delete.html', {'cliente': cliente })


#def cliente_delete(request, pk):
    cliente = Cliente.objects.get(pk=pk)
    cliente.delete()
    return redirect('cliente_list')

def servico_list(request):
    servicos = Servico.objects.all()
    return render(request, 'app/servico_list.html', {'servicos': servicos})


def servico_create(request):
    if request.method == 'POST':
        form = ServicoForm(request.POST, request.FILES)
        if form.is_valid():
            # Extraia os dados do formulário, incluindo os campos hora_inicio e hora_fim
            cliente = form.cleaned_data['cliente']
            data = form.cleaned_data['data']
            hora_inicio = form.cleaned_data['hora_inicio']
            hora_fim = form.cleaned_data['hora_fim']
            tipo_servico = form.cleaned_data['tipo_servico']
            fotos = form.cleaned_data['fotos']

            # Crie uma nova instância do Servico com os dados do formulário
            servico = Servico.objects.create(
                cliente=cliente,
                data=data,
                hora_inicio=hora_inicio,
                hora_fim=hora_fim,
                tipo_servico=tipo_servico,
                fotos=fotos
            )
            return redirect('servico_list')
    else:
        form = ServicoForm()
    return render(request, 'app/servico_form.html', {'form': form})

def servico_edit(request, pk):
    servico = get_object_or_404(Servico, pk=pk)
    if request.method == 'POST':
        form = ServicoForm(request.POST, request.FILES, instance=servico)
        if form.is_valid():
            # Extraia os dados do formulário, incluindo os campos hora_inicio e hora_fim
            cliente = form.cleaned_data['cliente']
            data = form.cleaned_data['data']
            hora_inicio = form.cleaned_data['hora_inicio']
            hora_fim = form.cleaned_data['hora_fim']
            tipo_servico = form.cleaned_data['tipo_servico']
            fotos = form.cleaned_data['fotos']

            # Atualize os dados do objeto Servico existente
            servico.cliente = cliente
            servico.data = data
            servico.hora_inicio = hora_inicio
            servico.hora_fim = hora_fim
            servico.tipo_servico = tipo_servico
            servico.fotos = fotos
            servico.save()
            return redirect('servico_list')
    else:
        form = ServicoForm(instance=servico)
    return render(request, 'app/servico_form.html', {'form': form})

def servico_delete(request, pk):
    servico = get_object_or_404(Servico, pk=pk)
    if request.method == 'POST':
        servico.delete()
        return redirect('servico_list')
    return render(request, 'app/servico_confirm_delete.html', {'servico': servico})